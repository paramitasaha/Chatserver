import Sidebar from "./Sidebar";
import Chats from "./Chats";
import React, { createContext } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { log } from "./login";


  const Home = () => {

    
    log('Inside Home');

    return(

        
        <div id="home">
           
          <Sidebar></Sidebar>
          <Chats></Chats>
          
        </div>
       

    );






}

export default Home;