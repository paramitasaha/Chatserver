
import React, { useContext } from "react";
import { useRef } from "react";

import Button from "./Button";

import { util,log } from "./login";




export default function Search() {

    let invitee = '';

    const inputRef = useRef(null);


   
    return (
        <div className="search">

            
            <button onClick={add} className="button">Add</button>
            <Button name="clear" onclick={clear}>Clear</Button>
            <input ref={inputRef}/> 



        </div>
    );


    function clear(){

       
            invitee = '';
            util.arbitary  = invitee;
            inputRef.current.value = '';

            //alert('clear '+internalValues.inviteList);
        

    }

    function add(){
        
        if(invitee !== ''){
        invitee = invitee+';'+ inputRef.current.value;
        util.arbitary  = invitee;
        }else {
            invitee = inputRef.current.value;
            util.arbitary  = invitee;


        }

        
        log('Inside Add method in Search jsx');

       // alert(internalValues.current.inviteList);

    }

    


}




