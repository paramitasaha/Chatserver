import Search from "./Search";
import Button from "./Button";


import { getUser_url, invite_url } from "./prop";
import axios from "axios";
import { useContext } from "react";

import { msgSent, util } from "./login";
import { log } from "./login";





const NavBar = () =>{



    let inviteeList = '';
    log('start NavBar');

    return(

        <div className="navBar">

           <Search></Search> 
           <Button name="Invite" onclick={invite}>Invite</Button>
           
        

        </div>

    );



    function invite(){
 
       log('invite() NavBar start:');
       msgSent.chatGrp = util.sessionId+";"+util.arbitary;
       util.arbitary = '';
       msgSent.sender = util.sessionId;
           
   
       axios.post(
                   invite_url,
                  msgSent,
               )
               .then((res) => {console.log(' invite done'+res.data
                
               )});


              

               log(' Inside invite() NavBar exit:');
    
  }


  }









export default NavBar;
