import React, { useContext, useRef, useState } from "react";
import Button from "./Button";

import Message from "./Message";
//import { internalValues, messg } from "../util";
import { logout_url, send_url } from "./prop";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";

import { msgSent, util } from "./login";
import { log } from "./login";



const Chat = () =>{

   const inputRef = useRef('');
   const navigate = useNavigate('');
   
      log('Inside chat start :');

    return(        
            <div className="chatbox">

                <div className="conversations">
                <Button name={"Send"}  onclick={sendMessage}>Send</Button>
                <Button name={"Logout"} onclick={logout}>Logout</Button>
                

                </div>

                <div className="history">
               
                <Message></Message>


                </div>
                <div className="messagesent">
                <textarea placeholder="write msg" className="textarea" ref={inputRef}></textarea>
                    
                
               
            </div>

           



        </div>

    );


    function logout(){
        //alert('sendMessage() invoked');
        log('logout chatstart :');
        msgSent.sender = util.sessionId;
        //alert(messg.sender +' want to logout');
        axios.post(logout_url, msgSent);
        navigate("/");

    }

    function sendMessage(){

        log('started sendMessage()');

        util.messageBoxText = inputRef.current.value;
        
        
        msgSent.sender = util.sessionId;
        msgSent.msg = util.messageBoxText;
        msgSent.chatGrp = util.chatGrp;//nternalValues.current.chatGrp;
       /* console.log("inside sendMessage session id :"+internalValues.current.sessionId);
        console.log('sender is : '+messg.current.sender);
        console.log(internalValues.current);
        */
        

        log("Inside sendMessage chat start:");

        axios.post(send_url,msgSent);

        inputRef.current.value = '';

        log('Inside sendMessage chat end:');



    }

    
}



export default Chat;