import React from 'react';
import { memo } from 'react';
 



const Button = ({name,onclick}) =>{

    console.log('child button render');

    return(
       
            <>  
            
            <button className='button' onClick={onclick}>{name}</button>
            </>

       

    );



}

export default  memo(Button); 




