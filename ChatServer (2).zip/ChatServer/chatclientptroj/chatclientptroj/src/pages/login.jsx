import React, { useState }  from "react";
import axios from "axios";
import { useRef } from "react";
import { useEffect } from "react";

import { base_url, getUser_url, test_url,accept_url} from "./prop";
import { validUser } from "./prop";
import Home from "./Home";
import { Link ,Outlet } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import { useContext } from "react";

import Button from "./Button";


export const util = {

  "chatGrp" :'',
  "history" : [],
  "sessionId" : '',
  "sender" :'',
  "passwd" : '',
  "msgCount" : 0,
  "lastReceivedMessageCount" :0,
  "receivedMsg" : '',
  "msgSub" : '',
  "msgBody" : '',
  "arbitary":'',
  "messageBox":'',
  "invitationSender": '',
  "arbitary1":'',


}




export const msgSent = {

  "sender":'',
  "passwd":'',
  "chatGrp":'',
  "msg":''

}



export default function Login() {


 

const inputRef1 =  useRef("");
const inputRef2 = useRef("");
  
const navigate = useNavigate("");



let user = '';


 


  return(

   



        <div className="formWrapper">
  
            
                <input type="text" placeholder="username" ref={inputRef1}></input>
                <input type="password" placeholder="password" ref={inputRef2}></input>
                        
                <button onClick={isValidUser}>Sign In</button>
                <p>Don't have an account?  
                  
                <Link to ="/register" >Register</Link>   </p>   
                

               
              

            
          
        </div>
        
        
       
    
      );
     
    
    
  



function isValidUser(){

    util.sender = inputRef1.current.value;
    util.passwd = inputRef2.current.value;

    console.log('messg sender '+ util.sender);

    msgSent.sender = util.sender;
    msgSent.passwd = util.passwd;
    

   axios.post(
                validUser, msgSent
               
            )
            .then((res) => {
               alert( res.data.msg);

               chat();                          
               
                            
            });

         

           
            
           


          }


          function chat(){

  

            let url = base_url+util.sender;
          
            //alert('opening a connection '+ url);
           
            const eventSource = new EventSource(url);
            eventSource.onerror = (e) => {
                // error log here
                // after logging, close the connection   
          
                
                eventSource.close();
              }
          
          
          
          
          
          
          
            
          
            eventSource.onopen = (e)=>{
          
              //alert('connection opened ');
          
             
             
          
            }  
           
           
           
            eventSource.onmessage = (event)=>{
          
              
          
          
            
              //alert(' on message called ');
             


              util.receivedMsg = event.data;
          
              
             
              //alert('data received : '+ utilValues.msg);
              parsePublishedMsg();
          
              if(util.msgSub === 'SentEvent'){
                
                //alert('message received inside sentEvent');
                log('inside sentevent  ')   ;
                
                //parsePublishedMsg();
          
                let msg = util.arbitary;

                
                //console.log('Chat msg Received from peers :'+utilValues.current.msgbody);
                let sender = util.arbitary1;
                //console.log('Message received from '+sender);
          
                util.history.push({id : sender, text : msg})  ;
                util.msgCount = util.msgCount + 1;
          
                      
                log('Inside SENTEVENT');
             
             
              } else if(util.msgSub==='UserId'){

               
                util.sessionId = util.arbitary;
                
                //console.log(' sessionId '+internalValues.current.sessionId);

                navigate("/home");                

                log('inside UserIDEvent');

                 
                //alert(' sender id : '+ internalValues.sessionId);
              }else if(util.msgSub === 'ChatInvitation'){
          
                //alert('chat invitation block called');
          
              // console.log('inside chatinvitation , sessionId :'+internalValues.current.sessionId);
                
              
          
                const confirmBox = confirm('Do you want to accept the invitation ?');
          
                if(confirmBox === true ){
          
                 
                  util.chatGrp = util.arbitary1;
                  
                  accept();

                  
                }
          
                
              log('inside chatinvitationevent ');
               
              }else if(util.msgSub==='AcceptInvitation'){
          
                

                util.chatGrp = util.arbitary1;
                util.invitationSender = util.arbitary;

                             
                log('inside acceptinvitationevent ');
              }
          
           
          
              
          }
          }
          
          
          
            
           // return () => eventSource.close();
          
          function accept(){
          
              //alert('accept func called');
              console.log(' accept invoked');
          
              msgSent.sender = util.sessionId;
                       
              msgSent.chatGrp = util.chatGrp;
          
             
             
              axios.post(accept_url,msgSent);
          
             
          
              console.log('inside accept method exited');
             // console.log(internalValues.current);

             
          
            
          }
          
          
          function parsePublishedMsg(){
          
            
            let msg = util.receivedMsg;
            
            //alert('msg received '+msg);

            console.log('received message '+msg);
          
            if(msg.split(":").length !== 3){
          
              alert('error msg ');
          
          
            }
          
            let msgArr = msg.split(":");
          
            util.msgSub = msgArr[0];
          
            
          
            util.arbitary1 = msgArr[1];
            util.arbitary = msgArr[2];
          
            
          
          }
          

          

          

          
        }

      export  function log(eventName){

          console.log(eventName+':'+JSON.stringify(util));
          console.log(eventName+':'+JSON.stringify(msgSent));
         
        }


        
