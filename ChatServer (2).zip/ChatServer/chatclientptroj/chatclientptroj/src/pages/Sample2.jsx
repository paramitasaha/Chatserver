import { useContext } from "react";
import { SampleContext } from "./sample";
import Sample3 from "../Sample3";

export default function Sample2(){

    const refvar = useContext(SampleContext);

    let val1 = refvar[0];
    let val2 = refvar[1];



    return (<><h1>I am sample2 ${refvar[0]} &&&&& ${refvar[1]}</h1><Sample3></Sample3></>);





}