import React, { useContext } from "react";
import Chat from "./Chat";
import Button from "./Button";
import { log } from "./login";


const Chats = () =>{

    

    

    log('Inside chats');

    return( <div className="chats">
        <Chat></Chat>
       
       
    </div>)



}


export default Chats;