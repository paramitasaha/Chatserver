import { useRef } from "react";
import { internalValues } from "../util";


export default function Input(){

    const inputRefMsg = useRef('');



    return(
        <div>
            

        </div>



    );

    function extractTextBoxData(){
        alert('extractTextBoxData invoked '+e.target.value);

    }
    


}

