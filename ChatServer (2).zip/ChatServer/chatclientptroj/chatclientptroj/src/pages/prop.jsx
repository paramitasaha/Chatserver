export const base_url = "/chatserver/webapi/chatserver/hello/";
export const validUser = "/chatserver/webapi/chatserver/tests/";
export const getUser_url = "/chatserver/webapi/chatserver/userId";
export const invite_url = "/chatserver/webapi/chatserver/invite";
export const test_url = "/ssews/webapi/broadcast/test";
export const accept_url = "/chatserver/webapi/chatserver/accept";
export const send_url = "/chatserver/webapi/chatserver/send";
export const logout_url = "/chatserver/webapi/chatserver/logout";

