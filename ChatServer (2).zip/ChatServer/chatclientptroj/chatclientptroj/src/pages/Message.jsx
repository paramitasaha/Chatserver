import { useContext, useEffect, useRef } from "react";

import { useState } from "react";
import parse from  'html-react-parser';

import { util } from "./login";

import { log } from "./login";
 

export default function Message (){


    let listMsgs  = [];
    const [historyCount,setHistoryCount] = useState('');
    const [loop , setLoop ] = useState(0);


    
    
    
   
    const receivedMsg = useRef('');
   

    let msgs = 'rendered !';

   // let history = [{"id":'' , "text":''},{"id":1, "text":'paramita'},{"id":2, "text":'paramita2'},{"id":3, "text":'paramita3'}]

    
   // console.log(internalValues.current);

   


    
   useEffect(()=>{


    let msgCount = util.msgCount;
    let lastReceivedMsgCount = util.lastReceivedMessageCount;

        let str = {"id":'id1' , "text":'testing'};

        
       // console.log('user effect invoked'+ receivedMsg.current);

           
        let timer = setTimeout(() => {
        

            
            msgCount = util.msgCount ;

            lastReceivedMsgCount = util.lastReceivedMessageCount;
            //console.log('user effect ');
           // console.log('no. of msg received so far msgCount in Message component :'+msgCount);
            //console.log('lastReceivedMsgCount :'+lastReceivedMsgCount);

            /*console.log('no. of history objects received : '+ history.current.length);
             */    
               //  listMsgs= internalValues.history.map((chatmsg)=>{'<p>'+ chatmsg.id+ ' : '+ chatmsg.text+'</p><br></br>'}) ;
              

               while(lastReceivedMsgCount< msgCount){
                    
                    //str = {id: 'id1' , text: 'text'};
                     str = util.history[lastReceivedMsgCount];

                    //console.log('last received msg '+str.text);


                    
                    lastReceivedMsgCount++;
 
                    //console.log(receivedMsg.current);
                    receivedMsg.current = receivedMsg.current+'<p>'+str.id +' : '+ str.text +'</p></br>';

                   // console.log('received msg :'+receivedMsg.current);
                    msgs = receivedMsg.current;

                    console.log(msgs);

                   util.lastReceivedMessageCount = lastReceivedMsgCount;
               }

                    

           setHistoryCount(historyCount => historyCount+receivedMsg.current);
           setLoop(loop => loop+1) ;

           //console.log('messages '+receivedMsg.current);
          
            if(lastReceivedMsgCount === 0){
        
             util.lastReceivedMessageCount = lastReceivedMsgCount ;    
            }else{

               util.lastReceivedMessageCount = lastReceivedMsgCount ;
            }
           
           // receivedMsg = '';
            
        }, 2000);

        
        },[loop]);

        
       // console.log('received msg :'+receivedMsg.current);

        let hello = '';


        hello= receivedMsg.current+'';

        //clearTimeout(timer);

        //{parse(receivedMsg)}

        //console.log('just before received msgs '+hello);*/


    return(

        <div  className="messages">
            Message
            {parse(hello)}           
        </div>


    );



}


