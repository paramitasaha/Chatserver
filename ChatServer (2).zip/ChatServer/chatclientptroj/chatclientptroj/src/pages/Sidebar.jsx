import React, { useContext, useEffect, useState } from "react";
import Search from "./Search";
import NavBar from "./NavBar";
import Users from "./Users";

import { useSearchParams } from "react-router-dom";

import { log } from "./login";

const Sidebar = () => {

   

    log('Inside Sidebar');

    const [updated, setUpdated] = useState(0);

    let users = '' ;
    let userString = '';

    function getUsers(){

       // console.log('chatGrp:'+internalValues.chatGrp);
        let users  = internalValues.current.chatGrp.split(';');

        console.log('users ......... '+ users);
        ///console.log(internalValues.chatGrp+' : length : '+users.length);

        let count = 0;

        

        while(count<users.length){

            userString = userString +'<h2>'+users[count]+'<h2>';
            count++;
        }

    }


  /*  useEffect(()=>{


        setTimeout(() => {

           // setUpdated(updated => updated+1);

            userString = getUsers();

            console.log('useString' + userString);

            
        }, 1000);
        

    },[updated]);*/

    return(
        <div className="sidebar">
           <NavBar></NavBar>
            
            
           <h1>User1</h1>
           <h2>User2</h2>
           <h3>User3</h3>
         </div>
         



    );








}


export default Sidebar;