const Users = () => {
    return(

        <div className="userWrapper">
        <div className="users">

           <label>User1</label>
           <label>User2</label>
           <label>User3</label>
           <label>User3</label>
        </div>
        </div>


    );






}

export default Users;

