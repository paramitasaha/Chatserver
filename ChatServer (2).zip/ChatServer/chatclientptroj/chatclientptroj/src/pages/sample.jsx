import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Link ,Outlet} from "react-router-dom";
import Register from "./resister";
import { createContext, useEffect, useRef, useState } from "react";
import Sample2 from "./Sample2";



export const SampleContext = createContext(null);

export default function App1() {


var refvar = useRef({"user":'ram'});

 
const [count , setCount] =useState(0);
useEffect(()=>{


  //setCount(count=>count+1);

  refvar.current = {"user":'jadu'};

},[count]);

  
 // refvar.current = {"user":'shyam'};
  refvar.current.user = 'madhu';

  const ref2 = useRef('chandda');

  
  
  
  return (

    <SampleContext.Provider  value={[refvar.current.user,ref2.current]} >
    <Sample2></Sample2>

    </SampleContext.Provider>
  );
}


