import React, { useState, useEffect } from 'react';
import axios from "axios";
import './App.css';

export default function Chatserver(){

    return (<div className=''>

     

          <input type="text" placeholder="username" ></input>
          <input type="password" placeholder="password" ></input>
          
          <button onClick={chat}>Sign In</button>
          <p>Don't have an account.Register</p>
        
      

    
  </div>
);


    
}





function axiosInvoke(){

  axios.get('http://localhost:8080/ssews/webapi/broadcast/test').then(
    response => {
        alert(response.data.name);
    });



}


function invoke(){

alert('clicked');


  const response =  fetch('http://localhost:8080/ssews/webapi/broadcast/test');

  alert(response);
  const data =   response.json ;

  alert(data);
  
  
  
   
}






function chat(){

    alert('opening a connection');
    // opening a connection to the server to begin receiving events from it
      
   const eventSource = new EventSource("ssews/webapi/broadcast");

  // const eventSource = new EventSource("/ssews/webapi/broadcast");


    
    eventSource.onerror = (e) => {
        // error log here
        // after logging, close the connection   

        
        alert('error caught' );

              
        eventSource.close();
      };







    

    eventSource.onopen = (e)=>{

      alert('connection opened');
      

    }  
   
    // attaching a handler to receive message events
    
   // while(eventSource != null && eventSource.readyState != eventSource.close){
    
    //alert('event source not null')
    eventSource.onmessage = (event) => {
     
      alert(' on message called' + event);
     
      const stockData = event.data;
     
        alert('data received'+ stockData);


    
    //} 
}
    // terminating the connection on component unmount
    
    
   // return () => eventSource.close();
  

  return (
    <h1>Hello</h1>
  );
};
