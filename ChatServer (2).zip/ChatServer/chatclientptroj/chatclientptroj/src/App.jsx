import { createContext, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import './css/register.css'
import './css/home.css'
import Register from './pages/resister'
import Login from './pages/login'
import Home from './pages/Home'
import { BrowserRouter, Routes, Route } from "react-router-dom";





function App() {

  return (
   <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}/>
          <Route index element={<Login />} />
          <Route path="home" element={<Home/>} />
          <Route path="register" element={<Register/>} />
          
       
      </Routes>
      </BrowserRouter>
  )
  
}

export default App
