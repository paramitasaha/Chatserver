import java.util.HashMap;

public class App {
	
	public static void main(String arg[]) {
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		String str = map.putIfAbsent("hello","paramita");
		str = map.putIfAbsent("hello", "aswin");
		System.out.println(str);
		
		
		
	}

}
