package com.jersey.chatserver;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;

import com.jersey.chatserver.pojo.Message;
import com.jersey.chatserver.util.ChatServerUtil;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/chatserver")
@Singleton
public class ChatServerResource {

	//done
	@GET
	@Produces(MediaType.SERVER_SENT_EVENTS)
	@Path("/hello/{user}")
	public EventOutput getConnection(@PathParam("user") String client) throws IOException{

		
		EventOutput eventOutput = ChatServerUtil.connect(client);
		

		return eventOutput;



		
	}
	
	
	
	
	/*@POST
	@Path("/userId")
	@Consumes(MediaType.APPLICATION_JSON)
	public void getUserId() {
		
		
		
		//ChatServerUtil.getUserId();
		
		
	}
	*/

	
	@POST
	@Path("/tests")
	@Consumes(MediaType.APPLICATION_JSON)
	public Message getTesting(Message msgSrc) {
		
			
		Message msg = new Message();
		msg.setMsg("Hello");
		
		return msg ;
		
		
	}
	

	@POST
	@Path("/send")

	@Consumes(MediaType.APPLICATION_JSON)
	public void publishMessage(Message message) {
		try {
			String chatGrp = message.getChatGrp();
			String msg = message.getMsg();
			String sender = message.getSender();


			System.out.println(" printing....."+msg);

			ChatServerUtil.publishMessage1(sender , chatGrp, msg);
		}catch(Exception excp) {

			excp.printStackTrace();
		}

	}

	//done

	@POST
	@Path("/invite")
	@Consumes(MediaType.APPLICATION_JSON)
	public void sendInvitation(Message message) {
		try {
			String sender = message.getSender();
			String chatInvitees = message.getChatGrp();

			System.out.println("chat invitees "+chatInvitees+ "sender "+sender);

			

			ChatServerUtil.sendInvite1(sender,chatInvitees);
		}catch(Exception excp) {

			excp.printStackTrace();
		}
	}

	//done

	@Path("/accept")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void acceptInvitation(Message message) {
		try {
			String invitee = message.getSender();

			String chatGrp = message.getChatGrp();

			System.out.println("chat grp "+chatGrp+" invitee "+ invitee);

			ChatServerUtil.acceptInvitation(invitee, chatGrp);
		}catch(Exception excp) {

			excp.printStackTrace();
		}

	}



	@Path("/logout")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)

	public void logout(Message msg) {

		try {
			String sender = msg.getSender();
			String chatGrp = msg.getChatGrp();


			System.out.println("logout "+ sender+" chatGrp "+ chatGrp);

			ChatServerUtil.logout1(sender, chatGrp);
		}catch(Exception excp) {

			excp.printStackTrace();
		}



	}


}
