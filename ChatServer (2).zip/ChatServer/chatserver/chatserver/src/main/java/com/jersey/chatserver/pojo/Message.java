package com.jersey.chatserver.pojo;

public class Message {
	
	private String sender ;
	
	private String chatGrp;
	
	private String msg;
	
	private String passwd;
	
	
	public void setPasswd(String passwd) {
		this.passwd = passwd;
		
	}
	
	public String getPasswd() {
		
		return passwd;
	}
	
	
	
	public void setSender(String sender) {
		
		this.sender = sender;
		
	}
	
	public String getSender() {
		
		return sender;
	}
	
	public void setChatGrp(String chatGrp) {
		
		
		this.chatGrp = chatGrp;
	}
	
	public String getChatGrp() {
		
		
		return chatGrp;
	}
	
	public void setMsg(String msg) {
		
		this.msg = msg;
	}
	
	public String getMsg() {
		
		return msg;
	}

}
