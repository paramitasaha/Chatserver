package com.jersey.chatserver.setup;

import javax.ws.rs.core.Application;

import org.glassfish.jersey.moxy.json.MoxyJsonFeature;
import org.glassfish.jersey.moxy.xml.MoxyXmlFeature;
import org.glassfish.jersey.server.ResourceConfig;

public class MyApplication extends ResourceConfig{
	
	
	public MyApplication() {
		
		packages(true , "com.jersey.chatserver","org.glassfish.jersey.examples.xmlmoxy","com.jersey.chatserver.util");
		
		//register(MoxyJsonFeature.class);
		
		register(MoxyXmlFeature.class);
		
		
	}
	
	

}
