package com.jersey.chatserver.util;

import java.io.IOException;
import java.util.Enumeration;
import java.util.EventObject;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;
import org.glassfish.jersey.server.Broadcaster;

public class ChatServerUtil {



	private static ConcurrentHashMap<String, SseBroadcaster> chatGrpConHashMap ; 
	private static ConcurrentHashMap<String, EventOutput> connections;

	private static ConcurrentHashMap<String, Integer> counts = new ConcurrentHashMap<String, Integer>();

	private static SseBroadcaster genBroadCBroadcaster = new SseBroadcaster();
	
	private static String lastLoggedInUser = "";


	public static ConcurrentHashMap<String, EventOutput> getConnection(){

		if(connections != null) {

			

			return connections;
		}else {

			
			connections = new ConcurrentHashMap<String, EventOutput>();
			return connections;
		}



	}

	public static boolean addConnection(String index , EventOutput event) {

		boolean isAdded = false;
		
		synchronized (connections) {
			
			isAdded =	getConnection().putIfAbsent(index, event)== null ? true : false;
			
		}
				
		
		
		return isAdded;

		
	}


	public static ConcurrentHashMap<String, SseBroadcaster> getchatGrpConHashMap(){

		if(chatGrpConHashMap != null) {

			return chatGrpConHashMap;

		}else {


			chatGrpConHashMap = new ConcurrentHashMap<String, SseBroadcaster>();
			
			
			return chatGrpConHashMap;
		}

	}


	public static boolean addChatGrpBroadCaster(String chatGrp, SseBroadcaster broadCaster ) {

		boolean isAdded = false;
		
		synchronized (chatGrpConHashMap) {
			
			isAdded = getchatGrpConHashMap().putIfAbsent(chatGrp, broadCaster)== null ? true : false;
			
		}
		
		return isAdded;
	}


	public static SseBroadcaster getChatGrpBroadCaster(String chatGrp ) {

		return getchatGrpConHashMap().get(chatGrp);

	}
	
	
	public static boolean publishMessage1(String sender,String chatGrp, String msg) {
		
		
		
		//String msgToBesent = "SentEvent:"+chatGrp+":"+msg;
		String msgToBesent = "SentEvent:"+sender+":"+msg;
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent event = eventBuilder
				.mediaType(MediaType.TEXT_HTML_TYPE)
				.data(String.class, msgToBesent)
				.build();
		
		synchronized (genBroadCBroadcaster) {
			
			makeReadyBroadcaster(sender, chatGrp, true, true);

			genBroadCBroadcaster.broadcast(event);
			
			makeReadyBroadcaster(sender, chatGrp, true, false);
			
		}

		
		
		System.out.println("Message Published");

		return true;
		
		
		
	}
	
	
	
	
	
	
	

	public static boolean publishMessage(String chatGrp , String msg ) {

		System.out.println("ChatGrp "+ chatGrp);
		
		
		
		SseBroadcaster broadCaster = getChatGrpBroadCaster(chatGrp);

		System.out.println("broadCaster "+broadCaster); 
		
		if(broadCaster == null) {
			return false;
		}

		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent event = eventBuilder.name(chatGrp)
				.mediaType(MediaType.TEXT_HTML_TYPE)
				.data(String.class, msg)
				.build();



		broadCaster.broadcast(event);
		
		System.out.println("Message Published");

		return true;

	}


	public static void logout(String sender,String chatGrp) throws IOException {
		EventOutput event = null;

		try {
			SseBroadcaster broadcaster = getChatGrpBroadCaster(chatGrp);

			broadcaster.remove(getConnection().get(sender));

			event = getConnection().get(sender);

			getConnection().remove(sender);


		}catch(Exception excp) {


		}finally {
			if(event != null)
				event.close();

		}





	}
	
	public static void logout1(String sender,String chatGrp) throws IOException {
		EventOutput event = null;

		try {
				

			System.out.println("sender to logout : "+sender);
			event = getConnection().get(sender);

			event.close();
			getConnection().remove(sender);
			
			Enumeration<String> senders = getConnection().keys();
			
			String client = "";
			
			int count = 0;
			while(senders.hasMoreElements()) {
				client = senders.nextElement();
				if(client.startsWith(sender.substring(0, sender.indexOf("#")))) {
					count = count++;
					break;
				}		 
				 
			 }
			
			if(count == 0) {
				
				counts.remove(sender.subSequence(0, sender.indexOf("#")-1));
			}
						
			
			
			System.out.println("Logged out successfully");


		}catch(Exception excp) {
			excp.printStackTrace();

		}finally {
			if(event != null)
				event.close();

		}





	}
	
	
	

	


	public static EventOutput connect(String sender) throws IOException{

		EventOutput eventOutput = new EventOutput();
		int count = 0;

		if(getConnection().containsKey(sender+"#1")) {
			System.out.println("Already connected ");

			eventOutput = new EventOutput();

			count = counts.get(sender);

			count++;
			System.out.println("counts before "+counts);
			counts.replace(sender,count);

			System.out.println("counts after "+counts);

			addConnection(sender+"#"+count, eventOutput);		


		} else {

			eventOutput = new EventOutput();
			System.out.println(" connection with "+sender);
			count++;
			
			counts.put(sender,1);
			addConnection(sender+"#1", eventOutput);
		}
		
		lastLoggedInUser = sender+"#"+count;
		
		System.out.println("last logged in user "+lastLoggedInUser);
		
		//////////////////////////////////////////////////
		
		String userEventMsg = "UserId::"+lastLoggedInUser;
		
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent UserIdEvent = eventBuilder
				.mediaType(MediaType.TEXT_PLAIN_TYPE)
				.data(String.class,userEventMsg)
				.build();	
		
		
		eventOutput.write(UserIdEvent);
		
		
		System.out.println(counts);
		
		
		return eventOutput;
		
		
		
	

	}
	
	
	/*public static void getUserId() {
		
		System.out.println("ChatServerResource.getUserId method invoked ....");
		
		String userEventMsg = "UserId::"+lastLoggedInUser;
		
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent UserIdEvent = eventBuilder
				.mediaType(MediaType.TEXT_PLAIN_TYPE)
				.data(String.class,userEventMsg)
				.build();	
		synchronized (genBroadCBroadcaster) {
			
		
				EventOutput lastLoggedInUserEvent = getConnection().get(lastLoggedInUser);
				
				System.out.println("who is last loggedin user ?????"+lastLoggedInUser);
				
				genBroadCBroadcaster.add(lastLoggedInUserEvent);
				
				genBroadCBroadcaster.broadcast(UserIdEvent);
				
				genBroadCBroadcaster.remove(lastLoggedInUserEvent);
				
				System.out.println("getUserId of util invoked");
		}
		
		
		
		
	}
*/

	/*public static String getChatGrp(String sender, String peers) {

			StringBuffer index = new StringBuffer(sender);

			for(String peer : peers.split(";")) {

				index.append("-");
				index.append(peer);


			}

			return index.toString();

		}*/

	
	
	
	public static void makeReadyBroadcaster(String sender , String chatGrp, boolean isPublish, boolean isAdd) {
		
		EventOutput event = null;
		
		String[] peers = chatGrp.split(";");

		int count = 0;
		int countEvent = 0;

		for(String peer : peers) {

			if(count != 0) {

				System.out.println("Peer "+peer);
				
				Enumeration<String> senders = getConnection().keys();
				
				
				while(senders.hasMoreElements())
				{
					String client = senders.nextElement();
					
					if(client.startsWith(peer+"#")) {
						event = getConnection().get(client);
						
						System.out.println("event 111111111111111111111 "+ event +"for client"+client);
						
						
						if(isAdd) {
						
							genBroadCBroadcaster.add(event);
							System.out.println("connection added  for "+client );
							
							
							
						}else {
							
							
							genBroadCBroadcaster.remove(event);
							System.out.println("connection removed for "+client);
							
							
						}
						
						countEvent++;
						

					}
				
					
					
				}
				
				
				
			}
			
			if(isPublish && count == 0) {
				
				
				System.out.println("sender : "+peer);
				
				Enumeration<String> senders = getConnection().keys();
				
				
				while(senders.hasMoreElements())
				{
					String client = senders.nextElement();
					
					if(client.startsWith(peer.substring(0,peer.indexOf("#")))) {
						event = getConnection().get(client);
						
						System.out.println("event 111111111111111111111 "+ event +"for client"+client);
						
						if(isAdd) {
						
							genBroadCBroadcaster.add(event);
							System.out.println("connection added for "+client);
						}else {
							
							genBroadCBroadcaster.remove(event);
							System.out.println("connection removed for "+client);
						}
						countEvent++;
						

					}
				
					
					
				}
				
				
				
			}

			count++;




		}
		if(isAdd) {
			System.out.println("BroadCaster successfully added events");
		}else {
			
			System.out.println("BroadCaster successfully removed events");
			
		}
		
		if(!isPublish)
			System.out.println("Invitation will be sent to peers : "+countEvent+ "for chatgrp :"+chatGrp);
		else {
			
			System.out.println("Message will be published ");
		}
		
		
		
		
		
		
	}
	
	
	
	
	public static void sendInvite1(String sender, String chatGrp) {
		
		System.out.println("sendinvite1 invoked");
		
		makeReadyBroadcaster(sender, chatGrp, false ,true);
		
		
		String msg = "ChatInvitation:"+chatGrp+":"+sender;
		
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent inviteEvent = eventBuilder
				.mediaType(MediaType.TEXT_PLAIN_TYPE)
				.data(String.class,msg)
				.build();
		
		//makeReadyBroadcaster(sender, chatGrp, false, true);

		
		
		genBroadCBroadcaster.broadcast(inviteEvent);

		System.out.println("Invitation sent to chatgrp : "+chatGrp);
		
		makeReadyBroadcaster(sender, chatGrp, false, false);
		
		System.out.println("sendinvite1 exited");
	
		
		
	}
	
	
	

	public static void sendInvite(String sender , String chatGrp ) {

		SseBroadcaster broadcaster;

		EventOutput event  = null ;

		if(getChatGrpBroadCaster(chatGrp)== null) {
			System.out.println(" for charGrp "+chatGrp + "broadcaster null initially");

			broadcaster = new SseBroadcaster();

			addChatGrpBroadCaster(chatGrp, broadcaster);
		}else {
			
			System.out.println(" for charGrp "+chatGrp + "broadcaster not null");

			broadcaster =getChatGrpBroadCaster(chatGrp);

		}

		String[] peers = chatGrp.split(";");

		int count = 0;
		int countEvent = 0;

		for(String peer : peers) {

			if(count != 0) {

				System.out.println("Peer "+peer);
				
				Enumeration<String> senders = getConnection().keys();
				
				
				while(senders.hasMoreElements())
				{
					String client = senders.nextElement();
					
					if(client.startsWith(peer+"#")) {
						event = getConnection().get(client);
						
						System.out.println("event 111111111111111111111 "+ event +"for client"+client);
						broadcaster.add(event);
						countEvent++;
						

					}
				
					
					
				}
				
				
				
			}

			count++;




		}
		
		System.out.println("Invitation will be sent to peers : "+countEvent+ "for chatgrp :"+chatGrp);

		
		
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		OutboundEvent inviteEvent = eventBuilder
				.mediaType(MediaType.TEXT_PLAIN_TYPE)
				.data(String.class,chatGrp)
				.build();

		broadcaster.broadcast(inviteEvent);

		System.out.println("Invitation sent to chatgrp : "+chatGrp);
	
		
		
		
		
	} 


	public static void acceptInvitation(String sender, String chatGrp) {

		//String peers[] = chatGrp.split(";");

		synchronized (genBroadCBroadcaster) {
			
			System.out.println("acceptInvitation invoked , sender : "+sender +" chatGrp : "+chatGrp);
			
			String invitationReceiver = chatGrp.split(";")[0];		
			
			EventOutput event = getConnection().get(invitationReceiver);
	
			System.out.println(" connection for "+invitationReceiver+" is :"+event);
			genBroadCBroadcaster.add(event);
	
	
			String msg = "AcceptInvitation:"+chatGrp+":"+sender;
			
			OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
			OutboundEvent acceptEvent = eventBuilder
					.mediaType(MediaType.TEXT_PLAIN_TYPE)
					.data(String.class,msg)
					.build();
	
	
	
			genBroadCBroadcaster.broadcast(acceptEvent);
	
			genBroadCBroadcaster.remove(event);
			
			System.out.println("acceptInvitation exited ");
		}

	}






}
