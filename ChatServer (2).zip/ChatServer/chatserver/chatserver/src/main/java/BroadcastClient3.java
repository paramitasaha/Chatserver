

import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.sse.EventInput;
import org.glassfish.jersey.media.sse.InboundEvent;
import org.glassfish.jersey.media.sse.SseFeature;
import org.glassfish.jersey.moxy.json.MoxyJsonFeature;

import com.jersey.chatserver.pojo.Message;

public class BroadcastClient3 {


	public static void main(String arg[]) throws IOException{

		Client client = ClientBuilder.newBuilder()
				.register(SseFeature.class).build();
		WebTarget target = client.target("http://localhost:8080/chatserver/webapi/chatserver/paramita4");






		EventInput eventInput = target.request().get(EventInput.class);
		//////////////////////////////////////////////////////////////






		

			Message msg = new Message();
			Response res = client.target("http://localhost:8080/chatserver/webapi/chatserver/userId").request(MediaType.APPLICATION_JSON).post(Entity.json(msg),Response.class);
			
			final InboundEvent inboundEvent = eventInput.read();

			System.out.println(inboundEvent.getName() + "; " + inboundEvent.readData(String.class));

			/*if(inboundEvent.getName().equalsIgnoreCase("ChatInvitation")) {


				Client cl = ClientBuilder.newClient();
				cl.register(MoxyJsonFeature.class);

				Message msg = new Message();

				msg.setSender("paramita1");
				msg.setChatGrp("paramita1;paramita4;paramita3");

				Response res = cl.target("http://localhost:8080/chatserver/webapi/chatserver/accept").request(MediaType.APPLICATION_JSON).post(Entity.json(msg),Response.class);

				System.out.println("paramita3 accepted");



			}*/












	



	}
}
