

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.moxy.json.MoxyJsonFeature;

public class PostMessages {

	
	public static void main(String arg[]) {
		
		

		Client cl = ClientBuilder.newClient();
		cl.register(MoxyJsonFeature.class);
		
		Response res = cl.target("http://localhost:8080/ssews/webapi/broadcast/send").request(MediaType.TEXT_PLAIN).post(Entity.text("hello all"), Response.class);
		
		System.out.println(res.readEntity(String.class));
		
		res.close();
		
	}
}
